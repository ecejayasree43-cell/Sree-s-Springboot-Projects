// RESUME UPLOAD ONLY 
document.getElementById("resumeForm")
    .addEventListener("submit", async function (event) {

        event.preventDefault();

        const file = document.getElementById("resumeFile").files[0];
        const jobId = document.getElementById("jobId").value;

        if (!file || !jobId) {
            alert("Please select resume and job role");
            return;
        }

        // Clear old result
        localStorage.removeItem("resumeResult");

        // Show loading (optional)
        const loading = document.getElementById("loading");
        if (loading) loading.style.display = "block";

        const formData = new FormData();
        formData.append("file", file);
        formData.append("jobId", jobId);

        try {

            const response = await fetch("/resume/upload", {
                method: "POST",
                body: formData
            });

            if (!response.ok) {
                throw new Error("Upload failed: " + response.status);
            }

            const result = await response.json();

            // Store result
            localStorage.setItem("resumeResult", JSON.stringify(result));



			
			
//  ONLY THIS LINE MATTERS FOR ACTIVATING DASHBOARD PAGE
		window.location.replace("/dashboard");

			

        } catch (error) {

            console.error(error);
            alert("Upload failed");

            if (loading) loading.style.display = "none";
        }
    });