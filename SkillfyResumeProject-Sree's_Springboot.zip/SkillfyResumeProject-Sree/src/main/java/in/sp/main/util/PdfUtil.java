package in.sp.main.util;


import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public class PdfUtil {
//	to extract text data from the pdf file

    private PdfUtil() {
    }

    public static String extractText(MultipartFile file)
            throws IOException {

        PDDocument document =
                Loader.loadPDF(file.getBytes());

        PDFTextStripper pdfTextStripper =
                new PDFTextStripper();

        String text =
                pdfTextStripper.getText(document);

        document.close();

        return text;
    }
}