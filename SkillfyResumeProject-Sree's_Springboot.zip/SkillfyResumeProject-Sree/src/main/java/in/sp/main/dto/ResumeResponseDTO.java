package in.sp.main.dto;


import java.util.List;

public class ResumeResponseDTO {

    private String candidateName;

    private List<String> skills;

    private int score;

    private List<String> suggestions;
    
    private List<String> missingSkills;

    public ResumeResponseDTO(String candidateName, List<String> skills, int score, List<String> suggestions,
			List<String> missingSkills) {
		super();
		this.candidateName = candidateName;
		this.skills = skills;
		this.score = score;
		this.suggestions = suggestions;
		this.missingSkills = missingSkills;
	}

	public List<String> getMissingSkills() {
		return missingSkills;
	}

	public void setMissingSkills(List<String> missingSkills) {
		this.missingSkills = missingSkills;
	}

	public ResumeResponseDTO() {
    }

    
    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public List<String> getSkills() {
        return skills;
    }

    public void setSkills(List<String> skills) {
        this.skills = skills;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public List<String> getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(List<String> suggestions) {
        this.suggestions = suggestions;
    }

    @Override
    public String toString() {
        return "ResumeResponseDTO{" +
                "candidateName='" + candidateName + '\'' +
                ", skills=" + skills +
                ", score=" + score +
                ", suggestions=" + suggestions +
                "Missing Values="+missingSkills+
                '}';
    }
}