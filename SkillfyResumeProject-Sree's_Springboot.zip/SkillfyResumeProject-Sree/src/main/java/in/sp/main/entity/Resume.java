package in.sp.main.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "resume")
public class Resume {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String candidateName;

    private String fileName;

    @Column(length = 5000)
    private String extractedSkills;

    private Integer score;
    
    @ManyToOne
    private Job job;

    @Column(length = 2000)
    private String missingSkills;

    @Column(length = 2000)
    private String suggestions;

    public Resume() {
    }

    public Resume(Long id, String candidateName,
                  String fileName,
                  String extractedSkills,
                  Integer score) {
        this.id = id;
        this.candidateName = candidateName;
        this.fileName = fileName;
        this.extractedSkills = extractedSkills;
        this.score = score;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getExtractedSkills() {
        return extractedSkills;
    }

    public void setExtractedSkills(String extractedSkills) {
        this.extractedSkills = extractedSkills;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
    
    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public String getMissingSkills() {
        return missingSkills;
    }

    public void setMissingSkills(String missingSkills) {
        this.missingSkills = missingSkills;
    }

    public String getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(String suggestions) {
        this.suggestions = suggestions;
    }

    @Override
    public String toString() {
        return "Resume{" +
                "id=" + id +
                ", candidateName='" + candidateName + '\'' +
                ", fileName='" + fileName + '\'' +
                ", extractedSkills='" + extractedSkills + '\'' +
                ", score=" + score +
                '}';
    }
}