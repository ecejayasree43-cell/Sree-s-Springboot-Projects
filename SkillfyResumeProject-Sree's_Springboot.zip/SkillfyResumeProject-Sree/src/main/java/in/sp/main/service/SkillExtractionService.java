package in.sp.main.service;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class SkillExtractionService {

    /* Predefined Skills Database  */
    
    private static final List<String> SKILL_DATABASE =
            Arrays.asList(

                    "java",
                    "spring boot",
                    "mysql",
                    "html",
                    "css",
                    "javascript",
                    "react",
                    "python",
                    "sql",
                    "excel",
                    "rest api",
                    "hibernate",
                    "bootstrap",
                    "machine learning",
                    "data analysis"
            );

    public List<String> extractSkills(String resumeText) {

        List<String> foundSkills = new ArrayList<>();

        String text = resumeText.toLowerCase();

        for (String skill : SKILL_DATABASE) {

            if (text.contains(skill)) {

                foundSkills.add(skill);
            }
        }

        return foundSkills;
    }
}
