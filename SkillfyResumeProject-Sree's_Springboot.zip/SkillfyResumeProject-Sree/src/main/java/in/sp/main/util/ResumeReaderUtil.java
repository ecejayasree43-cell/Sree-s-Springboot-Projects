package in.sp.main.util;

//Instead of checking file type everywhere, create one utility.
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public class ResumeReaderUtil {

//	it is to read the uploaded resume file may be docx or pdf,by MultipartFile
    private ResumeReaderUtil() {
    }

    public static String readResume(
            MultipartFile file)
            throws IOException {

        String fileName =
                file.getOriginalFilename();

        if (fileName == null) {
            throw new RuntimeException(
                    "Invalid File");
        }

        if (fileName.endsWith(".pdf")) {
            return PdfUtil.extractText(file);
        }

        if (fileName.endsWith(".docx")) {
            return DocxUtil.extractText(file);
        }

        throw new RuntimeException(
                "Only PDF and DOCX files are supported");
    }
}
