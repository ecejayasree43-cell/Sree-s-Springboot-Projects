package in.sp.main.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.sp.main.entity.Job;

@Repository
public interface JobRepository
        extends JpaRepository<Job, Long> {
	
//	it is for Later, when a user selects:Java Developer
//we need to fetch that job from database.
	
    Optional<Job> findByJobTitle(String jobTitle);

	

}
