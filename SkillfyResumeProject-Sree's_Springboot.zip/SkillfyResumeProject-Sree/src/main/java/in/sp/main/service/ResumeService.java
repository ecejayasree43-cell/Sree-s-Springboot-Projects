package in.sp.main.service;

 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.sp.main.dto.ResumeResponseDTO;
import in.sp.main.entity.Job;
import in.sp.main.entity.Resume;
import in.sp.main.repository.JobRepository;
import in.sp.main.repository.ResumeRepository;
import in.sp.main.util.ResumeReaderUtil;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Service
public class ResumeService {

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private SkillExtractionService skillExtractionService;

    @Autowired
    private JobMatchingService jobMatchingService;

    public ResumeResponseDTO analyzeResume(
            MultipartFile file,
            Long jobId) throws IOException {

        // Step 1: Read Resume
        String resumeText = ResumeReaderUtil.readResume(file);

        // Step 2: Extract Skills
        List<String> resumeSkills =
                skillExtractionService.extractSkills(resumeText);

        // Step 3: Fetch Job
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        // Step 4: Required Skills
        List<String> requiredSkills =
                Arrays.stream(job.getRequiredSkills().split(","))
                        .map(String::trim)
                        .map(String::toLowerCase)
                        .toList();

        // Step 5: Score
        int score = jobMatchingService.calculateScore(resumeSkills, requiredSkills);

        // Step 6: Missing Skills
        List<String> missingSkills =
                jobMatchingService.getMissingSkills(resumeSkills, requiredSkills);

        // Step 7: Suggestions
        List<String> suggestions =
                jobMatchingService.generateSuggestions(missingSkills);

        // Step 8: Save Resume (FIXED)
        Resume resume = new Resume();

        resume.setCandidateName(extractCandidateName(resumeText));
        resume.setFileName(file.getOriginalFilename());
        resume.setExtractedSkills(String.join(", ", resumeSkills));
        resume.setScore(score);

        //  IMPORTANT FIX
        resume.setJob(job);
        resume.setMissingSkills(String.join(", ", missingSkills));
        resume.setSuggestions(String.join(", ", suggestions));

        Resume savedResume = resumeRepository.save(resume);

        // Step 9: Return DTO
        ResumeResponseDTO response = new ResumeResponseDTO();
        response.setCandidateName(savedResume.getCandidateName());
        response.setSkills(resumeSkills);
        response.setMissingSkills(missingSkills);
        response.setScore(score);
        response.setSuggestions(suggestions);

        return response;
    }

    private String extractCandidateName(String text) {

        String[] lines = text.split("\\r?\\n");

        for (String line : lines) {
            line = line.trim();

            if (line.isEmpty()) continue;
            if (line.length() < 3) continue;
            if (line.toLowerCase().contains("resume")) continue;
            if (line.toLowerCase().contains("curriculum")) continue;
            if (line.contains("@")) continue;

            return line;
        }

        return "Unknown Candidate";
    }
}