package in.sp.main.service;


import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class JobMatchingService {

    /* Calculate Resume Score*/
    public int calculateScore(List<String> resumeSkills,
                              List<String> requiredSkills) {

        int matchedSkills = 0;

        for (String skill : requiredSkills) {

            if (resumeSkills.contains(skill.toLowerCase())) {

                matchedSkills++;
            }
        }

        if (requiredSkills.isEmpty()) {
            return 0;
        }

        return (matchedSkills * 100)
                / requiredSkills.size();
    }

    /* Find Missing Skills */

    public List<String> getMissingSkills(
            List<String> resumeSkills,
            List<String> requiredSkills) {

        List<String> missingSkills =
                new ArrayList<>();

        for (String skill : requiredSkills) {

            if (!resumeSkills.contains(skill.toLowerCase())) {

                missingSkills.add(skill);
            }
        }

        return missingSkills;
    }

    /* Generate Suggestions*/
    public List<String> generateSuggestions(
            List<String> missingSkills) {

        List<String> suggestions =
                new ArrayList<>();

        for (String skill : missingSkills) {

            suggestions.add(
                    "Learn " + skill
            );

            suggestions.add(
                    "Build projects using " + skill
            );
        }

        return suggestions;
    }
}