package in.sp.main.util;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public class DocxUtil {

//	to extract text data from the document file
    private DocxUtil() {
    }

    public static String extractText(MultipartFile file)
            throws IOException {

        XWPFDocument document =
                new XWPFDocument(file.getInputStream());

        XWPFWordExtractor extractor =
                new XWPFWordExtractor(document);

        String text =
                extractor.getText();

        extractor.close();
        document.close();

        return text;
    }
}
