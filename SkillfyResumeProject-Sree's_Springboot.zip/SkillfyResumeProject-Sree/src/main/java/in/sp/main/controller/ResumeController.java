package in.sp.main.controller;

  
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import in.sp.main.dto.ResumeResponseDTO;
import in.sp.main.entity.Resume;
import in.sp.main.repository.ResumeRepository;
import in.sp.main.service.ResumeService;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/resume")
@CrossOrigin("*")
public class ResumeController {

    @Autowired
    private ResumeService resumeService;

    @Autowired
    private ResumeRepository resumeRepository;

    /*Upload Resume + return saved result*/
    @PostMapping("/upload")
    public ResumeResponseDTO uploadResume(
            @RequestParam("file") MultipartFile file,
            @RequestParam("jobId") Long jobId) throws IOException {

        System.out.println("Received Job ID = " + jobId);

        return resumeService.analyzeResume(file, jobId);
    }

    /*Get All Resumes*/
    @GetMapping("/all")
    public List<Resume> getAllResumes() {
        return resumeRepository.findAll();
    }

    /* Get Resume By Id*/
    @GetMapping("/{id}")
    public Resume getResumeById(@PathVariable Long id) {
        return resumeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Resume Not Found"));
    }
}